import { ReactNode } from "react";

export interface WebsocketContextInterface {
    messages?: Array<string>; 
    sendWebsocketMessage(val: string): void;
}

export interface WebSocketContextProviderProps {
    children: ReactNode;
}