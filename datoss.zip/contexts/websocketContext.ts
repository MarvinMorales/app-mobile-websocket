import { createContext } from "react";
import { WebsocketContextInterface } from "@/interfaces";

export const websocketContext = createContext<WebsocketContextInterface>({
    messages: [],
    sendWebsocketMessage: () => {}
});