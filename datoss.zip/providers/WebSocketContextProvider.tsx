import React, { useEffect, useState } from "react";
import { websocketContext } from "@/contexts/websocketContext";
import configuration from "@/data/configuration.json";
import { WebSocketContextProviderProps } from "@/interfaces";


export default function WebSocketContextProvider({ children }: WebSocketContextProviderProps) {
    const [socket, setSocket] = useState<WebSocket | null>(null);
    const [messages, setMessages] = useState<Array<string>>([]);

    const { websocketURL } = configuration;

    useEffect(() => {
        const ws = new WebSocket(websocketURL); 
        setSocket(ws);
    
        ws.onopen = () => {
          console.log('Conexión WebSocket abierta');
        };
    
        ws.onmessage = (event) => {
          setMessages((prevMessages) => {
                return prevMessages ? [...prevMessages, event.data] : [event.data]
          }); 
        };
    
        ws.onerror = (error) => {
          console.log('Error en WebSocket:', error);
        };
    
        ws.onclose = () => {
          console.log('Conexión WebSocket cerrada');
        };
    
        return () => {
            if (ws.readyState === WebSocket.OPEN) 
              ws.close();
        };
    }, []); 

    const sendWebsocketMessage = (newMessage: string) => {
        if (socket && socket.readyState === WebSocket.OPEN) {
          socket.send(newMessage);
        } else console.error('WebSocket no está conectado');
    };

    return (
        <websocketContext.Provider value={{ messages, sendWebsocketMessage }}>
            { children }
        </websocketContext.Provider>
    );
}