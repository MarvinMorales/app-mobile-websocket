import "../global.css";
import React from "react";
import { Stack } from 'expo-router';
import { SafeAreaView } from "react-native-safe-area-context";
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import WebSocketContextProvider from "@/providers/WebSocketContextProvider";

export default function RootLayout() {
    return (
        <WebSocketContextProvider>
            <SafeAreaView className="flex-1">
                <GestureHandlerRootView className="flex-1">
                    <Stack screenOptions={{ headerShown: false }}>
                        <Stack.Screen name="index" />
                        <Stack.Screen name="(landing)" options={{ animation: "ios_from_left" }} /> 
                    </Stack>
                </GestureHandlerRootView>
            </SafeAreaView>
        </WebSocketContextProvider>
    );
}