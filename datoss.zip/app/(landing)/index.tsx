import React, { useCallback, useContext, useEffect, useState } from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { websocketContext } from "@/contexts/websocketContext";
import { Audio } from 'expo-av';
import { router } from "expo-router";

export default function Index() {
    const [recording, setRecording] = useState<Audio.Recording | null>(null);
    const [recordingUri, setRecordingUri] = useState<string | null>(null);
    const [isRecording, setIsRecording] = useState<boolean | null>(false);
    const { sendWebsocketMessage } = useContext(websocketContext);

    // Solicitar permisos para grabar audio
    const requestPermission = async () => {
        const { status } = await Audio.requestPermissionsAsync();
        if (status !== 'granted') 
            alert('Permission to access microphone is required!');
    };

    // eslint-disable-next-line
    const startRecording = async () => {
        try {
          const { recording } = await Audio.Recording.createAsync(
            Audio.RecordingOptionsPresets.HIGH_QUALITY
          );
      
          // Verifica que la instancia de recording no sea null o undefined
          if (!recording) {
            throw new Error('Failed to create recording instance');
          }
      
          setRecording(recording);
          setIsRecording(true);
          await recording.startAsync(); // Iniciar la grabación
          console.log('Recording started...');
        } catch (error) {
          console.error('Error al iniciar la grabación:', error);
        }
      };

    // Función para detener la grabación
    // eslint-disable-next-line
    const stopRecording = async () => {
        try {
            await recording?.stopAndUnloadAsync(); // Detener la grabación
            const uri = recording?.getURI(); // Obtener URI del archivo grabado
            setRecordingUri(uri as string); // Guardar URI para reproducirlo más tarde
            console.log('Grabación detenida, URI:', uri);
            setIsRecording(false);
        } catch (error) {
            console.error('Error al detener la grabación:', error);
        }
    };

    const handleRedirection = () => {
        router.navigate("/(landing)/Page2");
    }

    const sendMessage = useCallback(() => {
        sendWebsocketMessage(JSON.stringify({ type: "Hello" }))
    }, [sendWebsocketMessage]);

    useEffect(() => { requestPermission() }, []);

    return (
        <View className="flex-1 bg-neutral-800 justify-center items-center">
            <Text onPress={handleRedirection} className="text-white mb-4">
                { isRecording ? 'Grabando...' : 'Listo para grabar' }
            </Text>
            <TouchableOpacity activeOpacity={.8} onPress={sendMessage} className="px-5 py-4 rounded-[4px] bg-blue-500">
                <Text className="text-white">{isRecording ? 'Detener Grabación' : 'Empezar Grabación'}</Text>
            </TouchableOpacity>
            {recordingUri && (
                <Text className="mt-10">
                    Grabación guardada en: { recordingUri }
                </Text>
            )}
        </View>
    );
}