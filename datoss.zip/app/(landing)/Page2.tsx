import React, { useCallback, useContext } from "react";
import { Text, View } from "react-native";
import { websocketContext } from "@/contexts/websocketContext";

export default function Page2() {
    const { sendWebsocketMessage } = useContext(websocketContext);

    const sendMessage = useCallback(() => {
        sendWebsocketMessage(JSON.stringify({ type: "Lalala" }))
    }, [sendWebsocketMessage]);

    return (
        <View className="flex-1 flex justify-center items-center bg-neutral-950">
            <Text onPress={sendMessage} className="text-white">Page2</Text>
        </View>
    );
}