import React from "react";
import { Stack } from 'expo-router';

export default function LandingLayout() {
    return (
        <Stack 
            screenOptions={{ 
                headerShown: true, 
                headerTintColor: "white", 
                headerTitleAlign: "center",
                headerTitle: "Press to record audio",
                statusBarBackgroundColor: "#151515",
                headerStyle: { backgroundColor: "#1b1b1b" }
            }}
        >
            <Stack.Screen name="index" options={{ animation: "slide_from_right",  }} />
            <Stack.Screen name="Page2" options={{ animation: "slide_from_left" }} />
        </Stack>
    );
}