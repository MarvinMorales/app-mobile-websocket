import { create } from 'zustand';

export type GenericDataObject = {
    [key: string]: unknown;
}

export interface StoreState {
    socket: WebSocket | null;
}
  
export const useStore = create<StoreState & { 
    setUpdateStoreValue: <K extends keyof StoreState>(key: K, value: StoreState[K]) => void 
}>((set) => ({
    socket: null,

    // Función genérica con tipos
    setUpdateStoreValue: <K extends keyof StoreState>(key: K, value: StoreState[K]) => {
        set((state) => ({ ...state, [key]: value, }));
    }
}));
